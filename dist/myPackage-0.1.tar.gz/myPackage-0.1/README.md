This package was created in the process of learning how to build my python package in EDSA.

# How to install
it's quite easy to install, proceed to my setup and follow the instructions below:
###### 